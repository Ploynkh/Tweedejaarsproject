Step1.
 Have the following modules installed:
   Flask
   Pandas
   Numpy

Step2.
  Run the app.py file

Step3.
  In your browser, enter: http://localhost:5000/

