from flask import Flask, render_template, request
import pandas as pd
import numpy as np
import math
import os

#read the readme file to use the dashboard.

app = Flask(__name__)

@app.route("/")
def start():
    return render_template("start.html")


@app.route("/charging", methods=["GET", "POST"])
def charging():
    if request.method == "POST":
        soc_now = float(request.form["soc_now"])
        soc_target = float(request.form["soc_target"])
        battery_kwh = float(request.form["battery_kwh"])
        current_hr = int(request.form["current_hr"])

        immediate_mode = request.form.get("immediate_mode") == "on"

        if soc_target <= soc_now or battery_kwh <= 0:
            return render_template("index.html", error="Invalid input: target must be higher than current, and battery > 0.")

        # Load data
        BASE_DIR = os.path.dirname(os.path.abspath(__file__))
        availability_data = {}
        availability_folder = os.path.join(BASE_DIR, "predicted_availability")
        for fname in os.listdir(availability_folder):
            if fname.endswith("_hourly_total_availability.csv"):
                location = fname.replace("_hourly_total_availability.csv", "")
                df = pd.read_csv(os.path.join(availability_folder, fname))
                availability_data[location] = df

        try:
            prices   = pd.read_csv(os.path.join(BASE_DIR, "predicted_prices.csv"))
            energy   = pd.read_csv(os.path.join(BASE_DIR, "predicted_energy_consumption.csv"))
            sessions = pd.read_csv(os.path.join(BASE_DIR, "predicted_sessions.csv"))
            delays   = pd.read_csv(os.path.join(BASE_DIR, "hourly_departure_prediction.csv"))
        except Exception as e:
            return render_template("index.html", error=f"Failed to load required CSVs: {e}")

        charge_power = 140.0
        kwh_needed = battery_kwh * (soc_target - soc_now) / 100
        minutes_needed = (kwh_needed / charge_power) * 60
        hours_needed = math.ceil(minutes_needed / 60)

        if immediate_mode:
            start_total_minutes = current_hr * 60
            end_total_minutes = start_total_minutes + int(minutes_needed)
            end_hour = (end_total_minutes // 60) % 24
            end_minute = end_total_minutes % 60
            start_time_str = f"{current_hr:02d}:00"
            end_time_str = f"{int(end_hour):02d}:{int(end_minute):02d}"
            output_hours = f"{start_time_str}–{end_time_str}"

            minute_level_cost = 0.0
            for m in range(int(minutes_needed)):
                abs_minute = start_total_minutes + m
                hr = (abs_minute // 60) % 24
                price_row = prices[prices["hour"] == hr]
                if not price_row.empty:
                    price = price_row["predicted_price_per_kwh"].values[0]
                    minute_level_cost += (charge_power / 60) * price
            minute_level_cost = round(minute_level_cost, 2)

            availability_at_start = {}
            availability_warnings = []
            for loc, df in availability_data.items():
                match = df[df["hour"] == current_hr]
                if not match.empty:
                    availability_at_start[loc] = int(match["total_predicted_available"].values[0])
                else:
                    availability_at_start[loc] = "N/A"
                    availability_warnings.append(f"Warning: no availability data for {loc} at hour {current_hr}")

            return render_template("result.html", soc_now=soc_now, soc_target=soc_target,
                                battery_kwh=battery_kwh, output_hours=output_hours,
                                kwh_needed=round(kwh_needed, 1), hours_needed=hours_needed,
                                total_hours=int(minutes_needed // 60),
                                total_minutes=int(round(minutes_needed % 60)),
                                minute_level_cost=minute_level_cost,
                                availability_at_start=availability_at_start,
                                availability_warnings=availability_warnings,
                                start_time_str=start_time_str)

        total_hours = int(minutes_needed // 60)
        total_minutes = int(round(minutes_needed % 60))

        energy["hour"]   = (current_hr + energy.hour_ahead) % 24
        sessions["hour"] = (current_hr + sessions.hour_ahead) % 24
        delays["hour"]   = delays["hour"] % 24

        df = (prices
            .merge(energy[["hour", "predicted_energy_kwh"]], on="hour")
            .merge(sessions[["hour", "predicted_sessions"]], on="hour")
            .merge(delays[["hour", "predicted_departure_delay_minutes"]], on="hour")
            .sort_values("hour")
            .reset_index(drop=True))

        cheap_thr   = df.predicted_price_per_kwh.quantile(0.25)
        quiet_thr   = df.predicted_sessions.median()
        lowload_thr = df.predicted_energy_kwh.quantile(0.40)

        full_day = df.copy()
        full_day["eligible"] = (
            (full_day.predicted_price_per_kwh <= cheap_thr) &
            (full_day.predicted_sessions <= quiet_thr) &
            (full_day.predicted_energy_kwh <= lowload_thr) &
            (full_day.predicted_departure_delay_minutes >= minutes_needed)
        )



        order = list(range(current_hr, 24)) + list(range(0, current_hr))
        cand = df.set_index("hour").loc[~df.duplicated("hour")].reindex(order).reset_index()

        cand["eligible"] = (
            (cand.predicted_price_per_kwh <= cheap_thr) &
            (cand.predicted_sessions <= quiet_thr) &
            (cand.predicted_energy_kwh <= lowload_thr) &
            (cand.predicted_departure_delay_minutes >= minutes_needed)
        )

        cand["cost"] = cand.predicted_price_per_kwh * charge_power
        min_total_cost = float("inf")
        chosen = []

        def ends_within_window(start_hr, duration):
            end_hr = (start_hr + duration) % 24
            if current_hr + 7 >= 24:
                return start_hr < 24 and (end_hr <= (current_hr + 7) % 24 or end_hr >= current_hr)
            else:
                return current_hr <= start_hr and end_hr <= (current_hr + 7)

        for i in range(len(cand) - hours_needed + 1):
            block = cand.iloc[i : i + hours_needed]
            start_hr = block.iloc[0].hour
            end_hr = (start_hr + hours_needed) % 24

            hours_ahead = (start_hr - current_hr) % 24
            if hours_ahead > 7:
                continue

            if not ends_within_window(start_hr, hours_needed):
                shift_back = 1
                while shift_back <= start_hr - current_hr:
                    new_start = start_hr - shift_back
                    new_block = cand[cand["hour"].isin(range(new_start, new_start + hours_needed))]
                    if len(new_block) < hours_needed:
                        shift_back += 1
                        continue
                    if not ends_within_window(new_start, hours_needed):
                        shift_back += 1
                        continue
                    cost = new_block["cost"].sum()
                    if cost < min_total_cost:
                        chosen = list(new_block.hour)
                        min_total_cost = cost
                    break
            else:
                cost = block["cost"].sum()
                if cost < min_total_cost:
                    chosen = list(block.hour)
                    min_total_cost = cost

        if chosen:
            start_hour = int(chosen[0])
            start_total_minutes = start_hour * 60
            end_total_minutes = start_total_minutes + int(minutes_needed)
            end_hour = (end_total_minutes // 60) % 24
            end_minute = end_total_minutes % 60

            start_time_str = f"{start_hour:02d}:00"
            end_time_str = f"{int(end_hour):02d}:{int(end_minute):02d}"
            output_hours = f"{start_time_str}–{end_time_str}"
        else:
            output_hours = "No viable window found"
            start_time_str = "N/A"

        minute_level_cost = 0.0
        for m in range(int(minutes_needed)):
            abs_minute = start_total_minutes + m
            hr = (abs_minute // 60) % 24
            price = df.loc[df.hour == hr, "predicted_price_per_kwh"].values[0]
            minute_level_cost += (charge_power / 60) * price
        minute_level_cost = round(minute_level_cost, 2)

        availability_at_start = {}
        availability_warnings = []
        if chosen:
            for loc, df in availability_data.items():
                match = df[df["hour"] == start_hour]
                if not match.empty:
                    availability_at_start[loc] = int(match["total_predicted_available"].values[0])
                else:
                    availability_at_start[loc] = "N/A"
                    availability_warnings.append(f"Warning: no availability data for {loc} at hour {start_hour}")
        else:
            availability_at_start = {loc: "N/A" for loc in availability_data}
            availability_warnings = [f"Warning: no availability window found, data incomplete or conditions unmet."]

        return render_template("result.html", soc_now=soc_now, soc_target=soc_target,
                        battery_kwh=battery_kwh, output_hours=output_hours,
                        kwh_needed=round(kwh_needed, 1), hours_needed=hours_needed,
                        total_hours=total_hours, total_minutes=total_minutes,
                        minute_level_cost=minute_level_cost,
                        availability_at_start=availability_at_start,
                        availability_warnings=availability_warnings,
                        start_time_str=start_time_str)

    return render_template("index.html")

if __name__ == "__main__":
    BASE_DIR = os.path.dirname(os.path.abspath(__file__))
    predicted_prices = pd.read_csv(os.path.join(BASE_DIR, "predicted_prices.csv"))
    predicted_prices['hour'] = pd.to_datetime(predicted_prices['hour'], format='%H')
    app.run(debug=True)
